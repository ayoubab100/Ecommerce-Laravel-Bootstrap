<p align="center"><img src="https://laravel.com/assets/img/components/logo-laravel.svg"></p>
<p align="center">Shopping Cart Solution - Laravel and Bootstrap</p>

## Bootsrap Responsive Online Shop with beautiful metro style administration!

Current versions
* Laravel Framework 5.5.3 (https://laravel.com/)
* Bootstrap v3.3.7 (http://getbootstrap.com)


